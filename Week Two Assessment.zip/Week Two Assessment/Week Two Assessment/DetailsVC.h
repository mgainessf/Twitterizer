//
//  DetailsVC.h
//  Week Two Assessment
//
//  Created by Aaron B on 1/22/16.
//  Copyright © 2016 Bikis Design. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NationalPark.h"

@interface DetailsVC : UIViewController
@property NationalPark *selectedPark;
@property NSIndexPath *selectedIndexPath;


@end
